package com.example.alpbaba.controllers;

import javafx.fxml.FXML;

public class AdminDashboardController {

    @FXML
    private void handleCreateOperator() {
        // Implement create operator functionality
    }

    @FXML
    private void handleViewReports() {
        // Implement view reports functionality
    }
}
