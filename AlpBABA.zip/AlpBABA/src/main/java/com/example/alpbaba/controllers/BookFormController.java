package com.example.alpbaba.controllers;

import javafx.fxml.FXML;
import javafx.scene.control.TextField;

public class BookFormController {

    @FXML
    private TextField titleField;

    @FXML
    private TextField authorField;

    @FXML
    private TextField genreField;

    @FXML
    private TextField inventoryField;

    @FXML
    private void handleSave() {
        // Implement save book functionality
    }
}
