package com.example.alpbaba.controllers;

import javafx.fxml.FXML;

public class OperatorDashboardController {

    @FXML
    private void handleCreateReader() {
        // Implement create reader functionality
    }

    @FXML
    private void handleLendBook() {
        // Implement lend book functionality
    }

    @FXML
    private void handleReturnBook() {
        // Implement return book functionality
    }
}
