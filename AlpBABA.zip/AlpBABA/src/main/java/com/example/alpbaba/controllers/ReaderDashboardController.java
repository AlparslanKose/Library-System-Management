package com.example.alpbaba.controllers;

import javafx.fxml.FXML;

public class ReaderDashboardController {

    @FXML
    private void handleViewBooks() {
        // Implement view books functionality
    }

    @FXML
    private void handleProfile() {
        // Implement view profile functionality
    }
}
